This is a Community Solution, so please share your ideas, code, issues, etc.
If you have any new thing to be included, please open an issue to track it.
If you have developed some new features, please create a pull request, and I'll check it to merge in the main branch.

Thanks for your contribution!!

Demian.
