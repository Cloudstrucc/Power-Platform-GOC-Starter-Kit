This step is very usefull to add members to a Marketing Lists (accounts, contacts and leads)

For using this activity you must access here and select AddToMarketingList:

![](Add%20To%20Marketing%20List_w2.gif)

Then, you must select the Marketing List, an the record you want to add to the list. You must select only one of account, contact or lead:

![](Add%20To%20Marketing%20List_wf3.gif)

The full params description is:
* **Marketing List (required)** : the marketing List
* **Account** : Account reference to be added 
* **Contact** : Contact reference to be added
* **Lead** : Lead reference to be added

Note that you must select a record type to be added, on the same type of the MArketing List
