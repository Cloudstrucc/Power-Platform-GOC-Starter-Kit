This step allows you to Remove Role From a User.

For using this activity you must access here and select Remove Role From User.
Then in the activity you can fill all the parameters:

![](Remove%20Role%20From%20User_wf3.gif)

The Parameters are:
* Role: Select the Root Security Role (the parent one).
* User: Select the user
