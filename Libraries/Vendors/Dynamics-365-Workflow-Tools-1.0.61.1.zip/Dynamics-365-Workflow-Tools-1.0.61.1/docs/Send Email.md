This action is for Email Sending.
Now you can send all the previous created emails, and with this action, just execute the SendEmailRequest Method for these emails.

For using this action, please select "Send Email":
![](Send%20Email_wf1.gif)

Then, you must pass the Email reference to be send:

![](Send%20Email_wf2.gif)

Finnaly, as an output parameters you can get the final subjet with the CRM token:

![](Send%20Email_wf3.gif)
