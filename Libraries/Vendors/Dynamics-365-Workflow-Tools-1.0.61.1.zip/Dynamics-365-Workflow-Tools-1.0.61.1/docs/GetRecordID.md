This Action allows you to get a string with thew GUID of any record, from a record URL.

For using this action, just select it from the list:

![](GetRecordID1.gif)

And then, set the parameters:

![](GetRecordID2.gif)

Finally, ypu can use the GUID as a text field:

![](GetRecordID3.gif)
