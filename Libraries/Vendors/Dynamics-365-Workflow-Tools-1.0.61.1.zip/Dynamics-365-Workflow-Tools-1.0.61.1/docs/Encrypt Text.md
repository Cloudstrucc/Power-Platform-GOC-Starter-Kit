Encrypt Text action allow to retrieve the MD5 hash image of a text. Really use for Password fields.

For using this action, we can select the action:

![](Encrypt%20Text_wf1.gif)

Pass the parameter with the string to be Encrypt:

![](Encrypt%20Text_wf3.gif)

and then we can use the output parameter with the Hash:

![](EncryptText1.png)


If we use this action, the result of the MD5 is like this:

![](EncryptText2.png)
