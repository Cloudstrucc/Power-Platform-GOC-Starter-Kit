Disassociate Entity is an action for removing N-N relationships.

For using this action, just select the action:

![](Disassociate%20Entity_wf1.png)

Then, fill the 2 parameters, and that's all:

![](Disassociate%20Entity_wf2.png)

The paramaters are:
* Relationship Name: with the schame name of the N-N relationship
* Record URL: URL of the record to associate to the context entity of the workflow execution

