This step allows you to Qualify a Lead.

For using this activity you must access here and select Qualify Lead:
![](Qualify%20Lead_wf1.gif)


Then in the activity you can fill the following parameters: 
![](QualifyLead1.gif)

The Parameters are:
* Lead: Lead to be Qualified
* Create Account: true/false to set if we want to create a new account
* Create Contact: true/false to set if we want to create a new contact
* Create Opportunity: true/false to set if we want to create a new Opportunity
* Existing Account: to set an existing account to be set on new created Opportunity
* Existing Contact: to set an existing contact to be set on new created Opportunity
* LeadStatus: "3" for example for Qualify Status
