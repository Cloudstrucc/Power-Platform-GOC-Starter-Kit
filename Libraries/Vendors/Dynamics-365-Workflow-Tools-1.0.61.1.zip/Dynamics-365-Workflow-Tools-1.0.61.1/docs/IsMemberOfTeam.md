This step is for asking if a defined user is member of a team or not.

For using this activity you must access here and select the action:

![](IsMemberOfTeam1.gif)

An fill the parameters (User and Team):

![](IsMemberOfTeam2.gif)

Finally, you can use the result as you need (boolean):

![](IsMemberOfTeam3.gif)
