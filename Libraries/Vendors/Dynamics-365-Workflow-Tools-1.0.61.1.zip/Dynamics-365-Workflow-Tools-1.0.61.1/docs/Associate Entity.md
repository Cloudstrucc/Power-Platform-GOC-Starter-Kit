This action is for N-N creation with the Associate Method.

![](Associate%20Entity_wf1.gif)

![](Associate%20Entity_wf2.gif)

![](Associate%20Entity_wf3.png)
