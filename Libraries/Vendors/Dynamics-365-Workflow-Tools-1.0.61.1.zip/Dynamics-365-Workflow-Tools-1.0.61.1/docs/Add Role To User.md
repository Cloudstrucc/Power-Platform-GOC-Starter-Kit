This step allows you to Add security role to a User.


For using this activity you must access here and select Add Role To User.
Then in the activity you can fill all the parameters:

![](Add%20Role%20To%20User_wf2.gif)

The Parameters are:
* Role: Select the Root Security Role (the parent one).
* User: Select the user

