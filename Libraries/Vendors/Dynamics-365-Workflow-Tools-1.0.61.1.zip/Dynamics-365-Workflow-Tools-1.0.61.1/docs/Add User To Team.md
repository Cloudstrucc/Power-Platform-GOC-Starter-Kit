This action is for adding users to Teams.

![](Add%20User%20To%20Team_wf1.gif)

![](Add%20User%20To%20Team_wf2.gif)
