Here is the details for sharing a record to user:

![](Share%20Record%20With%20User_wf1.gif)
