This Action deletes the Audit History of one record. 


For use this in Workflows here are the steps:

![](DeleteRecordAuditHistory1.gif)

![](DeleteRecordAuditHistory2.gif)

Then if you have an Audit history like this one:
![](DeleteRecordAuditHistory3.gif)

After the action execution it will lilke this:
![](DeleteRecordAuditHistory4.gif)

