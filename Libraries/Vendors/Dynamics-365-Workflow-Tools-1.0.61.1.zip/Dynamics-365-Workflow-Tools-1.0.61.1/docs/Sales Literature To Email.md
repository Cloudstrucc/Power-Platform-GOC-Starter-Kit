This step allows you to retrieve Documents from Sales Literature, and attach them to a created Email record. 
You can also filter the attached Files by FileName.

For using this activity you must access here and select Sales Literature To Email:

![](SalesLiterature_wf1.gif)

Then in the activity you can fill all the parameters:

![](SalesLiterature_wf2.gif)
