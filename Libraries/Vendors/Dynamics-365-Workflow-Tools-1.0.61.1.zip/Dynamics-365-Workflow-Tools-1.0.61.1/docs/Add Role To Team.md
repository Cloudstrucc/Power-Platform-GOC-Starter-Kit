This step allows you to Add security role to a Team.


For using this activity you must access here and select Add Role To Team.
Then in the activity you can fill all the parameters:

![](Add%20Role%20To%20Team_wf2.gif)

The Parameters are:
* Role: Select the Root Security Role (the parent one).
* Team: Select the team
