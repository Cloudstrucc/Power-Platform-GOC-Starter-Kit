This step is for getting the total number of child records.

For using this activity you must access here and select the action:

![](CountChildEntityRecord1.gif)

An fill the parameters:

![](CountChildEntityRecord4.gif)

Finally, you can use the int Result of the app as you need:

![](CountChildEntityRecord3.gif)
