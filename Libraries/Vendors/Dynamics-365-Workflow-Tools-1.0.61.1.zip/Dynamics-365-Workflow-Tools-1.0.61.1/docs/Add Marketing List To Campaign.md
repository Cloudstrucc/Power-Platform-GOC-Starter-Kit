Documentation:

![](Add%20Marketing%20List%20To%20Campaign_wf2.gif)
