This action is for checking an associate relationship.
First, select the action:
![](Check%20Associate%20Entity_wf1.png)

Then, select the parameters:
![](Check%20Associate%20Entity_wf2.png)

Finnaly you can use the "Result" parameter as a Bool field:
![](Check%20Associate%20Entity_wf3.png)
