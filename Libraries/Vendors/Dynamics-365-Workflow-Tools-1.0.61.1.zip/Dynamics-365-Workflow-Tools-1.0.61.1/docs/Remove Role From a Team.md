This step allows you to Remove Role From a Team.

For using this activity you must access here and select Remove Role From Team.
Then in the activity you can fill all the parameters:

![](Remove Role From a Team_wf2.gif)

The Parameters are:
* Role: Select the Root Security Role (the parent one).
* Team: Select the user
