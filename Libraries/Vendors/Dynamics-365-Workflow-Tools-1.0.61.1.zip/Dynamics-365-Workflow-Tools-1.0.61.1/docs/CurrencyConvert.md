This Action allows you to convert an amount to any currency.
Convertion is based on Google: http://finance.google.com/finance/converter

For using this action, just select it from the list:

![](CurrencyConvert1.gif)

And then, set the parameters:

![](CurrencyConvert2.gif)

Finnaly you can use the result:

![](CurrencyConvert3.gif)
