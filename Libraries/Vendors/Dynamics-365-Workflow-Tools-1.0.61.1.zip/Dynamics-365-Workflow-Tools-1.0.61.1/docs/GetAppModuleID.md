This step is for getting the App ID from the App Name (not the dysplay name).

For using this activity you must access here and select the action:

![](GetAppModuleID1.gif)

Then, the the input parameter with the App Name, you can get the name from here:

![](GetAppModuleID2.gif)

An fill the parameter:

![](GetAppModuleID3.gif)

Finally, you can use the GUID of the app as you need:

![](GetAppModuleID4.gif)
