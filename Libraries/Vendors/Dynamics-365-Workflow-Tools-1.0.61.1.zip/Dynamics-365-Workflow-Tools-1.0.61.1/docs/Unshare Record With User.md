Unshare Record With User: Temoves all the privileges in one record for a Specific User

![](UnshareRecordWithUser1.gif)
