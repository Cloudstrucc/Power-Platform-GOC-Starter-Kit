This step allows you to Serialize an entity data to Json format.

For using this activity you must access here and select Entity Json Serializer:
![](Entity%20Json%20Serializer_wf1.gif)


Then in the activity you can fill the parameter with the Record URL to be serialized:
![](Entity%20Json%20Serializer_wf2.gif)

Finnaly, you can use the jSon string of the result:
![](Entity%20Json%20Serializer_wf3.gif)

An example of an account serialized to jSon:
![](Entity%20Json%20Serializer_wf4.gif)
