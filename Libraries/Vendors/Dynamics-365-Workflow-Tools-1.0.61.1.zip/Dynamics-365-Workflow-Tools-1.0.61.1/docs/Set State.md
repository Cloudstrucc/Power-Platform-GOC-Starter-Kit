Thiss action is for changing the state and statuscode of the main entity.
First, select the action from the list:
![](Set%20State_wf1.png)

and then, fill the params:
![](Set%20State_wf2.png)
