This Action allows you to get the Default Team of the User's Business Unit.

For using this action, just select it from the list:

![](RetrieveUserBUDefaultTeam1.gif)

Then, fill the parameter:

![](RetrieveUserBUDefaultTeam2.gif)

And you can use the Team in other actions:
![](RetrieveUserBUDefaultTeam3.gif)
