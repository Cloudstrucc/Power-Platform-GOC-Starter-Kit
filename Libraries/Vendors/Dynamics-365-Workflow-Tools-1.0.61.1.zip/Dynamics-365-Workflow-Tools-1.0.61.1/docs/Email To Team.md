This step allows you to add all the users from a Team on the "To" field of the email record.


For using this activity you must access here and select Email To Team:

![](Email%20To%20Team_wf1.gif)

And then you can fill the Parameters:

![](Email%20To%20Team_wf2.gif)

Then you can see all the users added on the email:

![](Email%20To%20Team_wf3.gif)
