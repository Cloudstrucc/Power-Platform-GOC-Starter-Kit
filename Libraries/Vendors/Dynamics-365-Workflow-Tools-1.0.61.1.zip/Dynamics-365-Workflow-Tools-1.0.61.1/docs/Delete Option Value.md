Delete Option Value is an action to Remove existing values from global and local OptionSets.
For using this action, first select the action:

![](Delete%20Option%20Value_wf1.png)

Then fill all the paramaters:

![](Delete%20Option%20Value_wf2.png)

The parameters are:
* **Global Option Set**: set if the OptionSet is Global or not
* **Attribute Name**: name of the local or global OptionSet
* **Entity Name**: (optional) with the name of the entity. Only required for local optionsets
* **Option Value**: Value of the new option to be added

NOTE: It could requires to publish customizations.
