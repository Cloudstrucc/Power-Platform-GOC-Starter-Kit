For using the OrgDbSettings Update&Retrieve actions, you can create a customized entity linke this one:

![](OrgDBSettingsExample1.png)

Customize a retrieve and Update workflows to fill and update the values so you can run the workflow to retrieve the values, and then, on update, change the values:

![](OrgDBSettingsExample2.png)

![](OrgDBSettingsExample3.png)
