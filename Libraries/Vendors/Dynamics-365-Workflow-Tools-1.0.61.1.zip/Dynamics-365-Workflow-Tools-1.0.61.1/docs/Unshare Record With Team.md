Unshare Record With Team: Removes all privileges shared for a record with a Team.

![](UnshareRecordWithTeam1.gif)
