Share Record With Team
![](ShareRecordWithTeam1.gif)
