This step is very usefull to check if the user that initialized the Workflow execution, is a mamber of a specified Team.

For using this activity you must access here and select CheckUserInTeam:

![](Check%20If%20User%20is%20in%20Team_wf2.gif)

Then, you must select the Team you want to check:

![](Check%20If%20User%20is%20in%20Team_wf3.gif)
The full params description is:
* **Team (required)** : the Team to be searched
* **IsUserInRole** : boolean with the result  

After that you can use the result on your fields:
![](Check%20If%20User%20is%20in%20Team_wf4.gif)
