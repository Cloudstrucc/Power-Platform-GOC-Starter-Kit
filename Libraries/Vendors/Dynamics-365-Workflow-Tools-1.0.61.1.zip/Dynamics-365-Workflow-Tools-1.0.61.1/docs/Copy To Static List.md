Documentation
![](Copy%20To%20Static%20List_wf2.gif)
