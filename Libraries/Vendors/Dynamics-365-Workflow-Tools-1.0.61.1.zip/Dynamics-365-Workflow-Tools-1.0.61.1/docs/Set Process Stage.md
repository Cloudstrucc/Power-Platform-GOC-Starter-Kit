This action is for changing the current stage of the active process of the record.

For use this feature, select the action:
![](Set%20Process%20Stage_wf1.gif)

Then select the parameters:

![](Set%20Process%20Stage_wf2.gif)
