This step is very usefull to remove members from a Marketing Lists (accounts, contacts and leads)

For using this activity you must access here and select RemoveFromMarketingList:

![](Remove%20From%20Marketing%20List_wf2.gif)

Then, you must select the Marketing List, an the record you want to remove from the list. You must select only one of account, contact or lead:

![](Remove%20From%20Marketing%20List_w33.gif)

The full params description is:
* **Marketing List (required)** : the marketing List
* **Account** : Account reference to be removed 
* **Contact** : Contact reference to be removed
* **Lead** : Lead reference to be removed

Note that you must select a record type to be added, on the same type of the Marketing List
