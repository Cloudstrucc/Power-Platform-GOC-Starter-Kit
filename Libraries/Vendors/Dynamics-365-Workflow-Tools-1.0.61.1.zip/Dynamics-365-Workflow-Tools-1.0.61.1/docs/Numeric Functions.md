This step allows you execute some basic numeric funcions with two decimal numbers.


For using this activity you must access here and select Numeric Functions.
Then in the activity you can fill all the parameters:

![](Numeric%20Functions_wf1.gif)

The parameters are two decimal numbers:

![](Numeric%20Functions_wf2.gif)

The Output Parameters are:
* Add: sum of the numbers.
* Subtract: subtraction of the numbers
* Multiply: multiplication of the numbers
* Divide: divide of the numbers

Then you can use the output numbers in other steps:
![](Numeric%20Functions_wf3.gif)

