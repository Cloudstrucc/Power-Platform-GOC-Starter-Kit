Documentation

![](Is%20Member%20Of%20Marketing%20List_wf2.gif)

![](Is%20Member%20Of%20Marketing%20List_wf3.gif)
