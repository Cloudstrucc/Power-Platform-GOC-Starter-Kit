The Geocode Address action allows you to retrieve the Latitude & Longitude from an address in a string.
This solution is based on BingMaps.

For using this activity, first you need to select the this action:

![](Geocode%20Address_wf1.gif)

Then you must set the two input parameters:

![](Geocode%20Address_wf2.gif)

NOTE: You must provide a Big Maps valid Key.

And Finnaly you can use the Latitude and Longitude output parameters:

![](Geocode%20Address_wf3.gif)

NOTE: the latitude and Longitude output parameters are numbers (Decimal)
