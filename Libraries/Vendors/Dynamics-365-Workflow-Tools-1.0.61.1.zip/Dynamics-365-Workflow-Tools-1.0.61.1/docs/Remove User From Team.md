This action is for removing user from a team,

![](Remove%20User%20From%20Team_wf1.gif)

![](Remove%20User%20From%20Team_wf3.gif)
